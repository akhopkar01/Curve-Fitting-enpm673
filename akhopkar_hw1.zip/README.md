These are the instructions to run the code.

Open the terminal and navigate to the "Code" Folder inside "nalindas_hw1.zip" extracted folder path.

Inside the "Problem 2" folder, there are two Problem 2 code files:

1. Problem_2_code.py - Before running the code, ensure that the file path for the dataset.csv in your system is correctly mentioned.Now, run the program in the terminal with the following command: "python3 Problem_2_code.py"

Please note, The program in its runtime will open figures of plots one after the other. To see the next plot, remember to close the current figure pop-ups.

2. Problem_2_code.ipynb - This is a Jupyter Notebook codeline structure. Open the code in Jupyter notebook. Ensure the file path for the dataset is correctly mentioned. Execute the program either serially, "Run All"

Problem 3:

Inside the "Problem 3" folder you will find the .py file named "Problem_3_code.py". Run the command from the terminal - "python Problem_3_code.py". This code is implemented in Python 2.7.12 so python3 might not work.
